export default function CapeVillaVista() {
  return (
    <div style={{ fontFamily: 'Arial, sans-serif', padding: '2rem' }}>
      <h1>CapeVillaVista</h1>
      <p>Modern Luxury Retreat on the Water in Cape Coral</p>
    </div>
  );
}